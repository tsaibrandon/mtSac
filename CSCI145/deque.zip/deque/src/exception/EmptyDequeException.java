package exception;

public class EmptyDequeException extends RuntimeException {
    public EmptyDequeException(String message) {
        super(message);
    }
} 