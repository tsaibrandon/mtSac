public enum ScanDetect {
    R, // radiation
    V, // vent
    W // weapon
}
