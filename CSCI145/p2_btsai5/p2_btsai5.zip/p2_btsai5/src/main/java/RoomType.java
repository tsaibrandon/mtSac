public enum RoomType {
    EMPTY,
    RADIATION,
    VENT,
    WEAPON
}
